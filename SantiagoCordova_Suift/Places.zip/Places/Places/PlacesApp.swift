//
//  PlacesApp.swift
//  Places
//
//  Created by Elvia Rosas on 18/08/25.
//

import SwiftUI

@main
struct PlacesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
